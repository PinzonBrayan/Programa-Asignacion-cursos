module ProyectoFproga2 {
	requires java.desktop;
	requires com.opencsv;
}