package ProyectoFproga2;

import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.opencsv.CSVWriter;

public class CursosDisponibles extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private DefaultTableModel tableModel;
    private DefaultTableModel realTimeTableModel; // Modelo para la tabla en tiempo real
    private JTable realTimeTable; // Tabla para mostrar datos en tiempo real

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    CursosDisponibles frame = new CursosDisponibles();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public CursosDisponibles() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 600); // Tamaño de la ventana
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Cursos Disponibles");
        lblNewLabel.setBounds(228, 21, 200, 20);
        contentPane.add(lblNewLabel);

        // Configurar la tabla principal
        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(52, 150, 500, 150); // Ubicación y tamaño de la tabla
        contentPane.add(scrollPane);

        // Configurar la tabla para datos en tiempo real
        realTimeTableModel = new DefaultTableModel(new String[] { "Nombres", "Apellidos", "Carne", "Cursos" }, 0);
        realTimeTable = new JTable(realTimeTableModel);
        JScrollPane realTimeScrollPane = new JScrollPane(realTimeTable);
        realTimeScrollPane.setBounds(52, 350, 500, 150);
        contentPane.add(realTimeScrollPane);

        // Botón para guardar datos
        JButton btnGuardarDatos = new JButton("Guardar Datos");
        btnGuardarDatos.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                File file = new File("./archivo.csv");

                try {
                    FileWriter outputFile = new FileWriter(file, true);
                    CSVWriter writer = new CSVWriter(outputFile, ';', CSVWriter.NO_QUOTE_CHARACTER, 
                                                      CSVWriter.DEFAULT_ESCAPE_CHARACTER, CSVWriter.DEFAULT_LINE_END);

                    String[] cabecera = { "Nombres", "Apellidos", "Carne", "Cursos" };

                    if (file.length() == 0) {
                        writer.writeNext(cabecera);
                    }

                    List<String[]> filas = new ArrayList<>();
                    int cantidad;
                    try {
                        cantidad = Integer.parseInt(JOptionPane.showInputDialog("Escribe la cantidad de cursos a evaluar"));
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Por favor ingresa un número válido.");
                        return;
                    }

                    for (int i = 0; i < cantidad; i++) {
                        String nombre = JOptionPane.showInputDialog("Escribe tus nombres");
                        String apellido = JOptionPane.showInputDialog("Escribe tus apellidos");
                        String carné = JOptionPane.showInputDialog("Escribe tu carné");
                        String curso = JOptionPane.showInputDialog("Escribe tu curso");

                        filas.add(new String[] { nombre, apellido, carné, curso });
                        realTimeTableModel.addRow(new String[] { nombre, apellido, carné, curso });
                    }

                    writer.writeAll(filas);
                    writer.close();

                    JOptionPane.showMessageDialog(null, "Datos guardados con éxito.");

                } catch (IOException exception) {
                    JOptionPane.showMessageDialog(null, "Error al guardar el archivo: " + exception.getMessage());
                    exception.printStackTrace();
                }
            }
        });
        btnGuardarDatos.setBounds(92, 71, 150, 30);
        contentPane.add(btnGuardarDatos);

        // Botón para abrir la página web
        JButton btnAbrirPagina = new JButton("Realizar Examen");
        btnAbrirPagina.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String url = "https://pinzonbrayan.github.io/InInstitucionEducactiva.github.io/";

                    if (Desktop.isDesktopSupported()) {
                        Desktop desktop = Desktop.getDesktop();
                        desktop.browse(new URI(url));
                    } else {
                        JOptionPane.showMessageDialog(null, "La funcionalidad de Desktop no está soportada.");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error al abrir la página: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        });
        btnAbrirPagina.setBounds(300, 71, 150, 30);
        contentPane.add(btnAbrirPagina);

        // Cargar los datos al iniciar la aplicación
        actualizarTabla();
    }

    // Método para cargar la tabla desde el archivo CSV al inicio
    private void actualizarTabla() {
        tableModel.setRowCount(0);

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\pinzo\\eclipse-workspace\\ProyectoFproga2\\src\\ProyectoFproga2\\Cursos.csv"))) {
            String line;
            boolean isHeader = true;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(";");
                if (isHeader) {
                    for (String header : values) {
                        tableModel.addColumn(header);
                    }
                    isHeader = false;
                } else {
                    tableModel.addRow(values);
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error al leer el archivo: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
